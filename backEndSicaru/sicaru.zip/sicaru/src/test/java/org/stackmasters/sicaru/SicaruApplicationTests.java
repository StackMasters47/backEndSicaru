package org.stackmasters.sicaru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SicaruApplicationTests {

	@Test
	void contextLoads() {
	}

}
